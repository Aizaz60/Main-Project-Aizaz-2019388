var url = 'https://openexchangerates.org/api/',
    apiKey = '079869f459204795a0e70699ce758543',
    currency = 'currencies.json',
    latest = 'latest.json';

window.onload = function() {
	"use strict";
    var fromcurrencyname = document.getElementById('fromcurrencyname');
    var fromcurrencyvalue = document.getElementById('fromcurrencyvalue');
    var tocurrencyname = document.getElementById('tocurrencyname');
    var tocurrencyvalue = document.getElementById('tocurrencyvalue');
    var amountdisplay = document.getElementById('amountdisplay');
    var fromcurrencyconvert = document.getElementById('fromcurrencyconvert');
    var tocurrencyconvert = document.getElementById('tocurrencyconvert');
    var btncurrenyconvert = document.getElementById('currenyconvert');

    fetch(url + currency + '?app_id=' + apiKey)
        .then(data => data.json())
        .then(obj => {
            var arr = [];
            for (let key in obj) {
                arr.push(`<option value=${key} ${(key === 'USD') ? 'selected' : ''}>[${key}] ${obj[key]}</option>`);
            }
            var htmlview = arr.join('');
            fromcurrencyname.innerHTML = htmlview;
            tocurrencyname.innerHTML = htmlview;
        })
        .catch(err => console.log(err));

    btncurrenyconvert.addEventListener('click', () => {
        amountdisplay.innerHTML = '...';
        fromcurrencyconvert.innerHTML = fromcurrencyname.value;
        tocurrencyconvert.innerHTML = 'loading';

        fetch(url + latest + '?app_id=' + apiKey)
            .then(data => data.json())
            .then(obj => {
                var x = obj.rates[fromcurrencyname.value],
                    y = obj.rates[tocurrencyname.value];
                tocurrencyvalue.value = (fromcurrencyvalue.value * y) / x;

                tocurrencyconvert.innerHTML = tocurrencyname.value;
                amountdisplay.innerHTML = y / x;
            })
            .catch(err => {
                alert('Some system error occur.');
                console.log('error: ' + err);
                amountdisplay.innerHTML = '??';
                tocurrencyconvert.innerHTML = 'Currency';
            });
    });

   
};

var country = document.querySelector('#tbcountry');
var weathername = document.querySelector('#weahtername');
var temperature = document.querySelector('#weathertemp');
var description = document.querySelector('#weatherdescription');
var button= document.querySelector('#btnsubmit');


button.addEventListener('click', function(nameftn){
	"use strict";
fetch('https://api.openweathermap.org/data/2.5/weather?q='+country.value+'&appid=079869f459204795a0e70699ce758543')
.then(response => response.json())
.then(data => {
  var tValue = data["weathername"]["temperature"];
  var nValue = data["nameftn"];
  var dValue = data["weather"][0]["description"];

  weathername.innerHTML = nValue;
  description.innerHTML = "Description - "+dValue;
  temperature.innerHTML = "Temperature - "+tValue;
  country.value ="";

})

.catch(err => alert("Wrong city/country name dsipalyed!"));
});